package com.example.animasiinstruktur.inputnama;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private String nomoe = "";
    TextView results;
    EditText txname;
    Button btnn,exit,reset;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        results = (TextView) findViewById(R.id.results);
        txname = (EditText) findViewById(R.id.txname);
        btnn = (Button) findViewById(R.id.btnn);
        exit = (Button) findViewById(R.id.exit);
        reset = (Button) findViewById(R.id.rst);

        btnn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                nomoe = txname.getText().toString();
                results.setText(nomoe);
            }
        });

        exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                moveTaskToBack(true);
                finish();
                System.exit(0);
            }
        });

        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                nomoe = "";
                txname.setText(nomoe);
                results.setText(nomoe);
            }
        });

    }
}
