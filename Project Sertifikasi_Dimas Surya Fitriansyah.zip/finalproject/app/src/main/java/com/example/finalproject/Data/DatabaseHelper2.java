package com.example.finalproject.Data;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.HashMap;

public class DatabaseHelper2 extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION =2;
    private static final String DATABASE_NAME = "karyawan.db";
    private static final String TABLE_NAME2 = "karyawan";
    private static final String COLUMN_ID2 = "id";
    private static final String COLUMN_NAMA = "nama";
    private static final String COLUMN_NIK = "nik";
    SQLiteDatabase db;

    private static final String TABLE_CREATE2 = "CREATE TABLE " + TABLE_NAME2 + " (" + COLUMN_ID2 + " INTEGER PRIMARY KEY autoincrement, "
            + COLUMN_NAMA + " TEXT NOT NULL, " + COLUMN_NIK + " TEXT NOT NULL" + " )";
    public DatabaseHelper2(Context context) {
        super(context,DATABASE_NAME,null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(TABLE_CREATE2);
        this.db = db;
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        String query2 = "DROP TABLE IF EXISTS " +TABLE_NAME2;
        db.execSQL(query2);
        this.onCreate(db);
    }

    public ArrayList<HashMap<String, String>> getAllData() {
        ArrayList<HashMap<String, String>> wordlist;
        wordlist = new ArrayList<HashMap<String, String>>();
        String selectQuery = "SELECT * FROM " + TABLE_NAME2;
        SQLiteDatabase database = this.getWritableDatabase();
        Cursor cursor = database.rawQuery(selectQuery, null);
        if (cursor.moveToFirst()){
            do {
                HashMap<String,String> map =new HashMap<String, String>();
                map.put(COLUMN_ID2, cursor.getString(0));
                map.put(COLUMN_NAMA, cursor.getString(1));
                map.put(COLUMN_NIK, cursor.getString(2));
                wordlist.add(map);
            }while (cursor.moveToNext());
        }

        Log.e("select sqlite", "" +wordlist);

        database.close();;
        return wordlist;
    }


    public void insert (String nama, String nik) {
        SQLiteDatabase database = this.getWritableDatabase();
        String queryValues = "INSERT INTO " + TABLE_NAME2 + " (nama, nik) " +"VALUES ( '" + nama + "', '" + nik + "')";
//        String queryValues = "INSERT INTO " + TABLE_NAME2 + " ("+ COLUMN_MAKUL +" ," + COLUMN_NILAI+ ") " +"VALUES ( '" + nama + "', '" + nik + "')";
        Log.e("insert data to database", "" + queryValues);
        database.execSQL(queryValues);
        database.close();
    }

    public void update (int id, String makul, String nilai){
        SQLiteDatabase database = this.getWritableDatabase();

        String updateQuery = "UPDATE " + TABLE_NAME2 + " SET " + COLUMN_NAMA + "='" + makul + "', "+ COLUMN_NIK + "='" + nilai +
                "'" + "WHERE " + COLUMN_ID2 + "=" + "'" + id + "'";
        Log.e("Update Data to database", updateQuery);
        database.execSQL(updateQuery);
        database.close();
    }

    public void delete (int id){
        SQLiteDatabase database = this.getWritableDatabase();
        String updateQuery = "DELETE FROM " + TABLE_NAME2 + " WHERE " + COLUMN_ID2 + "=" + "'" + id + "'";
        database.execSQL(updateQuery);
        database.close();
    }

}
