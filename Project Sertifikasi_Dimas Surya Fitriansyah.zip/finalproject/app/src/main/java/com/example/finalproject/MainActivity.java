package com.example.finalproject;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    ImageButton btntodo,btnmap, btnabout, btnkar, btnstrg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btntodo = findViewById(R.id.btntodo);
        btnmap = findViewById(R.id.btnmap);
        btnabout = findViewById(R.id.btnabout);
        btnstrg = findViewById(R.id.btnintst);
        btnkar = findViewById(R.id.btnkar);

        btnstrg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intintent = new Intent(MainActivity.this,  IntenalActivity.class);
                startActivity(intintent);
            }
        });

        btnkar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent dqlintent = new Intent(MainActivity.this,  DaftarNilaiActivity.class);
                startActivity(dqlintent);
            }
        });

        btnabout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(MainActivity.this);

                // set title dialog
                alertDialogBuilder.setTitle("ABOUT");

                // set pesan dari dialog
                alertDialogBuilder
                        .setMessage("Ini adalah aplikasi kumpulan aplikasi yang pernah dibuat sebelumnya")
                        .setIcon(R.mipmap.ic_launcher)
                        .setCancelable(false)
                        .setNegativeButton("OK",new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                // jika tombol ini diklik, akan menutup dialog
                                // dan tidak terjadi apa2
                                dialog.cancel();
                            }
                        });

                // membuat alert dialog dari builder
                AlertDialog alertDialog = alertDialogBuilder.create();

                // menampilkan alert dialog
                alertDialog.show();
            }
        });

        btnmap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent strgintent = new Intent(MainActivity.this,  MapsActivity.class);
                startActivity(strgintent);
            }
        });


        btntodo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent noteintent = new Intent(MainActivity.this, NoteActivity.class);
                startActivity(noteintent);
            }
        });

    }
}
