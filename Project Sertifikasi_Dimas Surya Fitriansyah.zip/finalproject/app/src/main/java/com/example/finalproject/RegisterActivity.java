package com.example.finalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;

public class RegisterActivity extends AppCompatActivity {
    EditText etUsername, etEmail, etPassword, etName;
    ImageButton btnRegister;
    TextView tvSignin;
    SqliteHelper sqliteHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        sqliteHelper = new SqliteHelper(this);

        etUsername = findViewById(R.id.etusername);
        etEmail = findViewById(R.id.etemail);
        etName = findViewById(R.id.etname);
        etPassword = findViewById(R.id.etpassword);
        btnRegister = findViewById(R.id.btnregister);
        tvSignin = findViewById(R.id.tvlogin);
        tvSignin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent loginIntent = new Intent(RegisterActivity.this, LoginActivity.class);
                startActivity(loginIntent);
                finish();
            }
        });

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (validate()) {
                    String UserName = etUsername.getText().toString();
                    String Email = etEmail.getText().toString();
                    String Name = etName.getText().toString();
                    String Password = etPassword.getText().toString();

                    //Check in the database is there any user associated with  this email
                    if (!sqliteHelper.isEmailExists(Email)) {

                        //Email does not exist now add new user to database
                        sqliteHelper.addUser(new User(null, UserName, Name, Email, Password));
                        Toast.makeText(RegisterActivity.this, "User created successfully! Please Login ", Toast.LENGTH_SHORT).show();
                        Intent loginIntent = new Intent(RegisterActivity.this, LoginActivity.class);
                        startActivity(loginIntent);
                        finish();
                    }else {

                        //Email exists with email input provided so show error user already exist
                        Toast.makeText(RegisterActivity.this, "Registration Failed ", Toast.LENGTH_SHORT).show();
                    }


                }
            }
        });
    }
    //This method is used to validate input given by user
    public boolean validate() {
        boolean valid = false;

        //Get values from EditText fields
        String UserName = etUsername.getText().toString();
        String Email = etEmail.getText().toString();
        String Name = etName.getText().toString();
        String Password = etPassword.getText().toString();

        //Handling validation for UserName field
        if (UserName.isEmpty()) {
            valid = false;
            etUsername.setError("Please enter valid username!");
        } else {
            if (UserName.length() > 4) {
                valid = true;
                etUsername.setError(null);
            } else {
                valid = false;
                etUsername.setError("Username is to short!");
            }
        }

        //Handling validation for Email field
        if (!Patterns.EMAIL_ADDRESS.matcher(Email).matches()) {
            valid = false;
            etEmail.setError("Please enter valid email!");
        } else {
            valid = true;
            etEmail.setError(null);
        }

        //Handling validation for Password field
        if (Name.isEmpty()) {
            valid = false;
            etName.setError("Please enter valid password!");
        } else {
            if (Password.length() > 2) {
                valid = true;
                etName.setError(null);
            } else {
                valid = false;
                etName.setError("Name is to short!");
            }
        }

        //Handling validation for Password field
        if (Password.isEmpty()) {
            valid = false;
            etPassword.setError("Please enter valid password!");
        } else {
            if (Password.length() > 5) {
                valid = true;
                etPassword.setError(null);
            } else {
                valid = false;
                etPassword.setError("Password is to short!");
            }
        }


        return valid;
    }
}
