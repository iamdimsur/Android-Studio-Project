package com.example.finalproject;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;

public class IntenalActivity extends AppCompatActivity implements View.OnClickListener{
    public static final String FILENAME = "namafile.txt";
    Button makeFile, editFile, readFile, deletreFile, btnbackm;
    TextView tvBaca;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intenal);
        makeFile = findViewById(R.id.btnMake);
        editFile = findViewById(R.id.btnUbah);
        readFile = findViewById(R.id.btnRead);
        deletreFile = findViewById(R.id.btnDelete);
        tvBaca = findViewById(R.id.txvRead);
        btnbackm = findViewById(R.id.btnBackm);

        btnbackm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent btnbackm = new Intent(IntenalActivity.this, MainActivity.class);
                startActivity(btnbackm);
                finish();
            }
        });

        makeFile.setOnClickListener(this);
        editFile.setOnClickListener(this);
        readFile.setOnClickListener(this);
        deletreFile.setOnClickListener(this);
    }

    void makeFile(){
        String isiFile = "Anda mendapatkan WARNING";
        File file = new File(getFilesDir(), FILENAME);

        FileOutputStream outputStream = null;
        try{
            file.createNewFile();
            outputStream = new FileOutputStream(file, true);
            outputStream.write(isiFile.getBytes());
            outputStream.flush();
            outputStream.close();
        } catch (Exception e){
            e.printStackTrace();
        }
    }

    void editFile(){
        String ubah = "Anda di PHK";
        File file = new File(getFilesDir(), FILENAME);

        FileOutputStream outputStream = null;
        try{
            file.createNewFile();
            outputStream = new FileOutputStream(file, false);
            outputStream.write(ubah.getBytes());
            outputStream.flush();
            outputStream.close();
        } catch (Exception e){
            e.printStackTrace();
        }
    }

    void readFile(){
        File sdcard = getFilesDir();
        File file = new File(sdcard, FILENAME);
        if(file.exists()){
            StringBuilder text = new StringBuilder();

            try {
                BufferedReader br = new BufferedReader(new FileReader(file));
                String line = br.readLine();

                while (line != null){
                    text.append(line);
                    line = br.readLine();
                }
                br.close();
            } catch (IOException e){
                System.out.println("Error" + e.getMessage());
            }
            tvBaca.setText(text.toString());
        }
    }

    void DeletreFile(){
        File file = new File(getFilesDir(), FILENAME);
        if (file.exists()){
            file.delete();
        }
    }

    public void onClick(View v){ jalankanPerintah(v.getId()); }

    public void jalankanPerintah(int id){
        switch(id){
            case R.id.btnMake:
                makeFile();
                break;
            case R.id.btnRead:
                readFile();
                break;
            case R.id.btnUbah:
                editFile();
                break;
            case R.id.btnDelete:
                DeletreFile();
                break;
        }
    }
}
