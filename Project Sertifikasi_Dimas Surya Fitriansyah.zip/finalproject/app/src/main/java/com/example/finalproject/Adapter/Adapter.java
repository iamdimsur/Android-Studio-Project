package com.example.finalproject.Adapter;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.finalproject.Data.DataNilai;
import com.example.finalproject.R;

import java.util.List;

public class Adapter extends BaseAdapter {

    private Activity activity;
    private LayoutInflater inflater;
    private List<DataNilai> items;

    public Adapter(Activity activity, List<DataNilai> items) {
        this.activity = activity;
        this.items = items;
    }

    @Override
    public int getCount() {
        return items.size();
    }

    @Override
    public Object getItem(int location) {
        return items.get(location);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int i, View convertview, ViewGroup parent) {
        if (inflater == null)
            inflater = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        if (convertview == null)
            convertview = inflater.inflate(R.layout.list_row, null);

        TextView id = (TextView) convertview.findViewById(R.id.id);
        TextView makul = (TextView) convertview.findViewById(R.id.makul);
        TextView nilai = (TextView) convertview.findViewById(R.id.nilai);

        DataNilai data = items.get(i);

        id.setText(data.getId());
        makul.setText(data.getNama());
        nilai.setText(data.getNik());

        return convertview;


    }
}