package com.example.finalproject;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.finalproject.Data.DatabaseHelper2;

public class AddEditNilaiActivity extends AppCompatActivity {
    EditText txt_id, txt_makul, txt_nilai;
    Button btn_submit, btn_cancel;
    DatabaseHelper2 SQLite = new DatabaseHelper2(this);
    String id, makul, nilai;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_edit_nilai);

        txt_id = (EditText)findViewById(R.id.txt_id);
        txt_makul = (EditText)findViewById(R.id.txt_makul);
        txt_nilai = (EditText)findViewById(R.id.txt_nilai);

        btn_submit = (Button)findViewById(R.id.btn_submitnilai);
        btn_cancel = (Button)findViewById(R.id.btn_cancel);

        id =getIntent().getStringExtra(DaftarNilaiActivity.TAG_ID);
        makul =getIntent().getStringExtra(DaftarNilaiActivity.TAG_NAMA);
        nilai =getIntent().getStringExtra(DaftarNilaiActivity.TAG_NIK);

        if (id == null || id == ""){
            setTitle("Add Data");
        }else{
            setTitle("Edit Data");
            txt_id.setText(id);
            txt_makul.setText(makul);
            txt_nilai.setText(nilai);
        }

        btn_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    if (txt_id.getText().toString().equals("")){
                        save();
                    }
                    else {
                        edit();
                    }
                } catch (Exception e){
                    Log.e("Submit", e.toString());
                }
            }
        });
        btn_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(AddEditNilaiActivity.this, DaftarNilaiActivity.class);
                startActivity(i);
            }
        });

    }
    public void onBackPressed(){
        finish();
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                blank();
                this.finish();
                return true;

            default:
                return super.onOptionsItemSelected(item);

        }
    }

    private void blank(){
        txt_makul.requestFocus();
        txt_id.setText(null);
        txt_makul.setText(null);
        txt_nilai.setText(null);

    }

    private void save(){
        if (String.valueOf(txt_makul.getText().toString()).equals(null) || String.valueOf(txt_makul.getText().toString()).equals("")
                || String.valueOf(txt_nilai.getText().toString()).equals(null) || String.valueOf(txt_nilai.getText().toString()).equals("")){
            Toast.makeText(getApplicationContext(), "Please input Makul or Nilai Fields", Toast.LENGTH_SHORT).show();
        }

        else {
            SQLite.insert(txt_makul.getText().toString().trim(), txt_nilai.getText().toString().trim());
            blank();
            finish();
        }
    }

    private void edit(){
        if (String.valueOf(txt_makul.getText().toString()).equals(null) || String.valueOf(txt_makul.getText().toString()).equals("")
                || String.valueOf(txt_nilai.getText().toString()).equals(null) || String.valueOf(txt_nilai.getText().toString()).equals("")){
            Toast.makeText(getApplicationContext(), "Please input Makul or Nilai Fields", Toast.LENGTH_SHORT).show();
        }

        else {
            SQLite.update(Integer.parseInt(txt_id.getText().toString().trim()),txt_makul.getText().toString().trim(), txt_nilai.getText().toString().trim());
            blank();
            finish();
        }
    }
}
