package com.example.finalproject;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.finalproject.Adapter.Adapter;
import com.example.finalproject.Data.DataNilai;
import com.example.finalproject.Data.DatabaseHelper2;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class DaftarNilaiActivity extends AppCompatActivity {
    ListView listView;
    AlertDialog.Builder dialog;
    List<DataNilai> itemList = new ArrayList<DataNilai>();
    Adapter adapter;
    DatabaseHelper2 SQlite = new DatabaseHelper2(this);

    public static final String TAG_ID = "id";
    public static final String TAG_NAMA = "nama";
    public static final String TAG_NIK = "nik";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_daftar_nilai);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null){
            getSupportActionBar().setTitle("Data Karyawan");
        }

        SQlite = new DatabaseHelper2(getApplicationContext());
        listView = findViewById(R.id.listView);

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent (DaftarNilaiActivity.this, AddEditNilaiActivity.class);
                startActivity(intent);
            }
        });


        adapter = new Adapter(DaftarNilaiActivity.this, itemList);
        listView.setAdapter(adapter);

        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(final AdapterView<?> parent, View view, final int position, long id) {
                final String idx = itemList.get(position).getId();
                final String makul = itemList.get(position).getNama();
                final String nilai = itemList.get(position).getNik();

                final CharSequence[] dialogitem = {"Edit", "Delete"};
                dialog = new AlertDialog.Builder(DaftarNilaiActivity.this);
                dialog.setCancelable(true);
                dialog.setItems(dialogitem, new DialogInterface.OnClickListener(){
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        switch (which) {
                            case 0:
                                Intent intent = new Intent(DaftarNilaiActivity.this, AddEditNilaiActivity.class);
                                intent.putExtra(TAG_ID, idx);
                                intent.putExtra(TAG_NAMA, makul);
                                intent.putExtra(TAG_NIK, nilai);
                                startActivity(intent);
                                break;

                            case 1:
                                SQlite.delete(Integer.parseInt(idx));
                                itemList.clear();
                                getAllData();
                                break;
                        }
                    }
                }).show();
                return false;

            }
        });
        getAllData();
    }
    private void getAllData(){
        ArrayList<HashMap<String,String>> row = SQlite.getAllData();

        for (int i = 0; i < row.size(); i++) {
            String id = row.get(i).get(TAG_ID);
            String poster = row.get(i).get(TAG_NAMA);
            String title = row.get(i).get(TAG_NIK);

            DataNilai data = new DataNilai();
            data.setId(id);
            data.setNama(title);
            data.setNik(poster);

            itemList.add(data);
        }
        adapter.notifyDataSetChanged();
    }


    @Override
    protected void onResume() {
        super.onResume();
        itemList.clear();
        getAllData();
    }

}
