package com.example.finalproject.Data;

public class DataNilai {

    private String id, nama, nik;

    public DataNilai(){

    }

    public DataNilai(String id, String nama, String nik){

        this.id = id;
        this.nama = nama;
        this.nik = nik;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getNik() {
        return nik;
    }

    public void setNik(String nik) {
        this.nik = nik;
    }
}
