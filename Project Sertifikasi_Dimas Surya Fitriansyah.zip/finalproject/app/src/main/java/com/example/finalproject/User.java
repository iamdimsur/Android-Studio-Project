package com.example.finalproject;

public class User {
    public String id;
    public String userName;
    public String email;
    public String name;
    public String password;

    public User(String id, String userName, String name, String email, String password) {
        this.id = id;
        this.userName = userName;
        this.email = email;
        this.name = name;
        this.password = password;
    }

}
