package com.example.animasiinstruktur.fixcalculator;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    TextView results;
    private double hasil ;
    private double angka1  ;
    private double angka2  ;
    EditText nil1,nil2;
    ImageButton btnplus, btnmin, btndiv, btnmul;
    Button btnreset;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        results = (TextView) findViewById(R.id.results);
        nil1 = (EditText) findViewById(R.id.nil1);
        nil2 = (EditText) findViewById(R.id.nil2);
        btndiv = (ImageButton) findViewById(R.id.btndiv);
        btnplus = (ImageButton) findViewById(R.id.btnplus);
        btnmin = (ImageButton) findViewById(R.id.btnmin);
        btnmul = (ImageButton) findViewById(R.id.btnmul);
        btnreset = (Button) findViewById(R.id.reset);

        btndiv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(nil1.getText().toString().length() > 0 && nil2.getText().toString().length() > 0){
                    angka1 = Double.parseDouble(nil1.getText().toString());
                    angka2 = Double.parseDouble(nil2.getText().toString());
                    hasil = angka1/angka2;
                    results.setText(Double.toString(hasil));
                } else {
                    Toast.makeText(getApplicationContext(), "Masukan Angka",Toast.LENGTH_LONG).show();
                }
            }
        });

        btnplus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(nil1.getText().toString().length() > 0 && nil2.getText().toString().length() > 0){
                    angka1 = Double.parseDouble(nil1.getText().toString());
                    angka2 = Double.parseDouble(nil2.getText().toString());
                    hasil = angka1+angka2;
                    results.setText(Double.toString(hasil));
                } else {
                    Toast.makeText(getApplicationContext(), "Masukan Angka",Toast.LENGTH_LONG).show();
                }
            }
        });

        btnmin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(nil1.getText().toString().length() > 0 && nil2.getText().toString().length() > 0){
                    angka1 = Double.parseDouble(nil1.getText().toString());
                    angka2 = Double.parseDouble(nil2.getText().toString());
                    hasil = angka1-angka2;
                    results.setText(Double.toString(hasil));
                } else {
                    Toast.makeText(getApplicationContext(), "Masukan Angka",Toast.LENGTH_LONG).show();
                }
            }
        });

        btnmul.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(nil1.getText().toString().length() > 0 && nil2.getText().toString().length() > 0){
                    angka1 = Double.parseDouble(nil1.getText().toString());
                    angka2 = Double.parseDouble(nil2.getText().toString());
                    hasil = angka1*angka2;
                    results.setText(Double.toString(hasil));
                } else {
                    Toast.makeText(getApplicationContext(), "Masukan Angka",Toast.LENGTH_LONG).show();
                }
            }
        });

        btnreset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                nil1.setText("");
                nil2.setText("");
                results.setText("");
                nil1.requestFocus();
            }
        });
    }
}
