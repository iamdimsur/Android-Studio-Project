package com.java.dimas.internalstorage;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;

public class InternalActivity extends AppCompatActivity implements View.OnClickListener {
    public static final String FILENAME = "namafile.txt";
    Button makeFile, editFile, readFile, deletreFile;
    TextView tvBaca;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_internal);

        makeFile = findViewById(R.id.btnMake);
        editFile = findViewById(R.id.btnUbah);
        readFile = findViewById(R.id.btnRead);
        deletreFile = findViewById(R.id.btnDelete);
        tvBaca = findViewById(R.id.txvRead);

        makeFile.setOnClickListener(this);
        editFile.setOnClickListener(this);
        readFile.setOnClickListener(this);
        deletreFile.setOnClickListener(this);
    }

    void makeFile(){
        String isiFile = "Coba isi data File text";
        File file = new File(getFilesDir(), FILENAME);

        FileOutputStream outputStream = null;
        try{
            file.createNewFile();
            outputStream = new FileOutputStream(file, true);
            outputStream.write(isiFile.getBytes());
            outputStream.flush();
            outputStream.close();
        } catch (Exception e){
            e.printStackTrace();
        }
    }

    void editFile(){
        String ubah = "Update isi Data FIle Text";
        File file = new File(getFilesDir(), FILENAME);

        FileOutputStream outputStream = null;
        try{
            file.createNewFile();
            outputStream = new FileOutputStream(file, false);
            outputStream.write(ubah.getBytes());
            outputStream.flush();
            outputStream.close();
        } catch (Exception e){
            e.printStackTrace();
        }
    }

    void readFile(){
        File sdcard = getFilesDir();
        File file = new File(sdcard, FILENAME);
        if(file.exists()){
            StringBuilder text = new StringBuilder();

            try {
                BufferedReader br = new BufferedReader(new FileReader(file));
                String line = br.readLine();

                while (line != null){
                    text.append(line);
                    line = br.readLine();
                }
                br.close();
            } catch (IOException e){
                System.out.println("Error" + e.getMessage());
            }
            tvBaca.setText(text.toString());
        }
    }

    void DeletreFile(){
        File file = new File(getFilesDir(), FILENAME);
        if (file.exists()){
            file.delete();
        }
    }

    public void onClick(View v){ jalankanPerintah(v.getId()); }

    public void jalankanPerintah(int id){
        switch(id){
            case R.id.btnMake:
                makeFile();
                break;
            case R.id.btnRead:
                readFile();
                break;
            case R.id.btnUbah:
                editFile();
                break;
            case R.id.btnDelete:
                DeletreFile();
                break;
                }
    }
}
