package com.example.admin.beanomedia;

import android.webkit.WebView;
import android.webkit.WebViewClient;

public class myBrowser extends WebViewClient {
    public boolean shouldOverdriveUrlLoading(WebView view, String url){
        view.loadUrl(url);
        return true;
    }
}
